package com.example.findnumbers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import com.example.findnumbers.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var count = 1

        binding.apply {
            btnStart.setOnClickListener {

                chronometer.base = SystemClock.elapsedRealtime()
                chronometer.start()
                count = 1
                textCount.text = count.toString()
                var numRand = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12",
                "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24")
                var viewRand = listOf(textView1, textView2, textView3, textView4, textView5, textView6,
                textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14,
                textView15, textView16, textView17, textView18, textView19, textView20, textView21,
                textView22, textView23, textView24)
            var shList = numRand.shuffled()
                for (i in shList.indices)
                viewRand[i].text = shList[i]
            }
            textView1.setOnClickListener {
                if (count.toString() == textView1.text) {
                    textView1.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView2.setOnClickListener {
                if (count.toString() == textView2.text) {
                    textView2.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView3.setOnClickListener {
                if (count.toString() == textView3.text) {
                    textView3.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView4.setOnClickListener {
                if (count.toString() == textView4.text) {
                    textView4.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView5.setOnClickListener {
                if (count.toString() == textView5.text) {
                    textView5.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView6.setOnClickListener {
                if (count.toString() == textView6.text) {
                    textView6.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView7.setOnClickListener {
                if (count.toString() == textView7.text) {
                    textView7.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView8.setOnClickListener {
                if (count.toString() == textView8.text) {
                    textView8.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView9.setOnClickListener {
                if (count.toString() == textView9.text) {
                    textView9.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView10.setOnClickListener {
                if (count.toString() == textView10.text) {
                    textView10.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView11.setOnClickListener {
                if (count.toString() == textView11.text) {
                    textView11.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView12.setOnClickListener {
                if (count.toString() == textView12.text) {
                    textView12.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView13.setOnClickListener {
                if (count.toString() == textView13.text) {
                    textView13.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView14.setOnClickListener {
                if (count.toString() == textView14.text) {
                    textView14.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView15.setOnClickListener {
                if (count.toString() == textView15.text) {
                    textView15.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView16.setOnClickListener {
                if (count.toString() == textView16.text) {
                    textView16.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView17.setOnClickListener {
                if (count.toString() == textView17.text) {
                    textView17.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView18.setOnClickListener {
                if (count.toString() == textView18.text) {
                    textView18.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView19.setOnClickListener {
                if (count.toString() == textView19.text) {
                    textView19.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView20.setOnClickListener {
                if (count.toString() == textView20.text) {
                    textView20.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView21.setOnClickListener {
                if (count.toString() == textView21.text) {
                    textView21.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView22.setOnClickListener {
                if (count.toString() == textView22.text) {
                    textView22.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView23.setOnClickListener {
                if (count.toString() == textView23.text) {
                    textView23.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }
            }
            textView24.setOnClickListener {
                if (count.toString() == textView24.text) {
                    textView24.text = ""
                    count++
                    textCount.text = count.toString()
                    if (count == 25)
                        chronometer.stop()
                }

            }
        }
    }
}